# Raddiwala
A platform to connect scrap buyers and sellers, a submission for ACM Hacklipse Hackathon
